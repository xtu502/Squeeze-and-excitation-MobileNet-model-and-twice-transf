﻿# -*- coding: utf-8 -*-
"""
Created on Sun Jun 16 22:23:24 2019

@author: HP
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Dec  8 07:11:11 2018

@author: HP
"""

from keras import backend as K
from keras import optimizers
import keras.backend.tensorflow_backend as KTF
import glob
from keras.layers import Input,Dense,Dropout,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,concatenate,Activation,ZeroPadding2D
import tensorflow as tf
import cv2
import numpy as np
import pandas as pd
import keras
from keras.models import load_model
from keras.layers import Activation, Dense
from matplotlib import pyplot as plt
from skimage import io,data
import time
from keras import layers
from keras.callbacks import ModelCheckpoint, TensorBoard
from keras.preprocessing.image import ImageDataGenerator

from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
now = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())

import os,sys
os.getcwd()
os.chdir("/home/cjd/15_Com_gen")

print(os.getcwd())
print (sys.version)


#import os
# 
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "1,2"

config = tf.ConfigProto()
config.gpu_options.allow_growth = True
keras.backend.tensorflow_backend.set_session(tf.Session(config=config))


import tensorflow as tf        #定义多分类Focal函数
def focal_loss(gamma=2.):            #多分类，不带alpha
    def focal_loss_fixed(y_true, y_pred):
        pt_1 = tf.where(tf.equal(y_true, 1), y_pred, tf.ones_like(y_pred))
        return -K.sum( K.pow(1. - pt_1, gamma) * K.log(pt_1)) 
    return focal_loss_fixed


def Conv2d_BN(x, nb_filter,kernel_size, padding='same',strides=(1,1),name=None):  
    if name is not None:  
        bn_name = name + '_bn'  
        conv_name = name + '_conv'  
    else:  
        bn_name = None  
        conv_name = None   
    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,activation='relu',name=conv_name)(x)  
#    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,name=conv_name)(x)
#    x = Lambda(swish)(x)
    x = BatchNormalization(axis=3,name=bn_name)(x)  
    return x  


def Conv_Block(inpt,nb_filter,kernel_size,strides=(1,1), with_conv_shortcut=False):  
    x = Conv2d_BN(inpt,nb_filter=nb_filter[0],kernel_size=(1,1),strides=strides,padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[1], kernel_size=(3,3), padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[2], kernel_size=(1,1), padding='same')  
    if with_conv_shortcut:  
        shortcut = Conv2d_BN(inpt,nb_filter=nb_filter[2],strides=strides,kernel_size=kernel_size)  
        x = add([x,shortcut])  
        return x  
    else:  
        x = add([x,inpt])  
        return x  


# 数据集
batch_size = 64 #每批训练数据量的大小，批量多设一些；GoogleNet批量值设为20 2^n
epochs = 30
MODEL_INIT = './obj_reco/init_model.h5'
MODEL_PATH = './obj_reco/tst_model.h5'
board_name1 = './obj_reco/stage1/' + now + '/'
board_name2 = './obj_reco/stage2/' + now + '/'
#train_dir = '/home/wkq/Projects/kerasVGG19/train_b'  # 训练集
#validation_dir='/home/wkq/Projects/kerasVGG19/test_b'  # 测试集

train_dir = './train_b'  # 训练集
validation_dir='./test_b'  # 测试集

img_size = (256, 256)  # 图片大小
#classes=list(range(1,5))
#classes=['1','2','3','4']
nb_train_samples = len(glob.glob(train_dir + '/*/*.*'))  # 训练样本数
nb_validation_samples = len(glob.glob(validation_dir + '/*/*.*'))  # 验证样本数


classes = sorted([o for o in os.listdir(train_dir)])  # 根据文件名分类
'''
#---------MobileNet迁移学习--------------------------------------------------------------
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

# 创建预训练模型
IMG_SHAPE=(256, 256, 3)

base_model = keras.applications.mobilenet.MobileNet(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_1_0_224_tf_no_top.h5')

for layer in base_model.layers:
    layer.trainable = False
    
# 增加全局平均池化层
x = base_model.output
x = GlobalAveragePooling2D()(x)
# 增加全连接层
x = Dense(1024, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 

x = Dense(512, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 
# softmax激活函数用户分类
#predictions = Dense(len(ont_hot_labels[0]), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg
predictions = Dense(len(classes), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)
# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
#model.compile(loss='categorical_crossentropy', optimizer=optimizers.Adadelta(), metrics=['accuracy'])
'''



#---------MobileNet_SE迁移学习--------------------------------------------------------------
from keras.applications.densenet import DenseNet121,preprocess_input
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

class SeBlock(keras.layers.Layer):   
    def __init__(self, reduction=4,**kwargs):
        super(SeBlock,self).__init__(**kwargs)
        self.reduction = reduction
    def build(self,input_shape):#构建layer时需要实现
    	#input_shape     
    	pass
    def call(self, inputs):
        x = keras.layers.GlobalAveragePooling2D()(inputs)
        x = keras.layers.Dense(int(x.shape[-1]) // self.reduction, use_bias=False,activation=keras.activations.relu)(x)
        x = keras.layers.Dense(int(inputs.shape[-1]), use_bias=False,activation=keras.activations.hard_sigmoid)(x)
        return keras.layers.Multiply()([inputs,x])    #给通道加权重
        #return inputs*x 

# 创建预训练模型
IMG_SHAPE=(256, 256, 3)

base_model = DenseNet121(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet121_weights_tf_dim_ordering_tf_kernels_notop.h5', input_shape=IMG_SHAPE, include_top=False)
#base_model = keras.applications.mobilenet.MobileNet(input_shape=IMG_SHAPE,include_top=False, 
#weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_1_0_224_tf_no_top.h5')
#base_model = keras.applications.MobileNetV2(input_shape=IMG_SHAPE,include_top=False, 
#weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')


for layer in base_model.layers:
    layer.trainable = False
    
# 增加全局平均池化层
x = base_model.output
x  = Conv2d_BN(x,nb_filter=512,kernel_size=(3,3),strides=(1,1),padding='same')
x=SeBlock()(x)
x = GlobalAveragePooling2D()(x)

# 增加全连接层
x = Dense(1024, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 

# softmax激活函数用户分类
predictions = Dense(len(classes), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)
# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop  optimizer=optimizers.Adadelta()

#这段代码用来将model.summary() 输出保存为文件
from contextlib import redirect_stdout   
with open('model_summary.txt', 'w') as f:
    with redirect_stdout(f):
        model.summary(line_length=200,positions=[0.30,0.60,0.7,1.0])




'''
#-------Inception_resnet_v2迁移模型---------------
from keras.applications.inception_resnet_v2 import InceptionResNetV2,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
import tensorflow as tf

base_model = InceptionResNetV2(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/inception_resnet_v2_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
 
for layer in base_model.layers:
    layer.trainable = False
    
x = base_model.output

x = GlobalAveragePooling2D()(x) 
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)
#编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''


'''
#--------Inception_DensNet迁移模型----------------------------------------------------------
from keras.applications.densenet import DenseNet121,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
#from keras.layers import Input,Add,Dense,Dropout,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,concatenate
from keras.layers import *        #导入Lamda层 

def Inception(x,nb_filter):  
    branch1x1 = Conv2d_BN(x,nb_filter,(1,1), padding='same',strides=(1,1),name=None)  
  
    branch3x3 = Conv2d_BN(x,nb_filter,(1,1), padding='same',strides=(1,1),name=None)  
    branch3x3 = Conv2d_BN(branch3x3,nb_filter,(3,3), padding='same',strides=(1,1),name=None)  
  
    branch5x5 = Conv2d_BN(x,nb_filter,(1,1), padding='same',strides=(1,1),name=None)  
#    branch5x5 = Conv2d_BN(branch5x5,nb_filter,(1,1), padding='same',strides=(1,1),name=None)
    branch5x5 = Conv2d_BN(branch5x5,nb_filter,(3,3), padding='same',strides=(1,1),name=None)
    branch5x5 = Conv2d_BN(branch5x5,nb_filter,(3,3), padding='same',strides=(1,1),name=None)
  
    branchpool = MaxPooling2D(pool_size=(3,3),strides=(1,1),padding='same')(x)  
    branchpool = Conv2d_BN(branchpool,nb_filter,(1,1),padding='same',strides=(1,1),name=None)  
  
    x = concatenate([branch1x1,branch3x3,branch5x5,branchpool],axis=3)    
    return x  

base_model = DenseNet121(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet121_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
#base_model = DenseNet201(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet201_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False, input_shape=(224, 224, 3))

 
for layer in base_model.layers:
    layer.trainable = False

x = base_model.output
x = Inception(x,256)  
#x = Conv2d_BN(x,512,(3,3),strides=(1,1),padding='same')  
##添加自己的全链接分类层
x = GlobalAveragePooling2D()(x) 
#x = Dense(1024,activation='relu')(x)  
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)
# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''


'''
#----------融合 STN+MobileNet迁移---------------------------------------------------------------
#-----------------------------------------------------------------------------------
from keras.layers import Dense, GlobalAveragePooling2D, GlobalMaxPooling2D, Input, add, Flatten  
from spatial_transformer_network import SpatialTransformer
#from seya.spatial_transformer import SpatialTransformer
#from seya.layers.attention import SpatialTransformer
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D
#MobileNet迁移学习包
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

b = np.zeros((2, 3), dtype='float32')
b[0, 0] = 1
b[1, 1] = 1
W = np.zeros((50, 6), dtype='float32')
weights = [W, b.flatten()]
#localization net,得到仿射变换系数theta
input_shape=(256,256,3)

from keras import backend as K  
K.set_image_dim_ordering('tf')  

locnet = Sequential()
locnet.add(MaxPooling2D(pool_size=(2,2), input_shape=input_shape))
locnet.add(Convolution2D(20, 5, 5,dilation_rate=(2, 2)))  #dilation_rate=(2, 2)
locnet.add(BatchNormalization())
locnet.add(MaxPooling2D(pool_size=(2,2)))
locnet.add(Convolution2D(20, 5, 5,dilation_rate=(2, 2)))
locnet.add(BatchNormalization())

locnet.add(Flatten())
locnet.add(Dense(50))
locnet.add(Activation('relu'))
locnet.add(Dense(6, weights=weights)) #输出仿射变换系数theta
#locnet.add(Activation('sigmoid'))

# 创建MobileNet预训练模型
#K.set_learning_phase(0)
IMG_SHAPE=(256, 256, 3)
base_model = keras.applications.mobilenet.MobileNet(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_1_0_224_tf_no_top.h5')

for layer in base_model.layers:
    layer.trainable = False

input_layer=Input(shape=(256,256,3))
model = Sequential()
#model_input = Input(shape=img_dim)

x=base_model.output
x = SpatialTransformer(localization_net=locnet,
                         output_size=(224,224,3))(input_layer)

#x=base_model(x)
#x = Conv2d_BN(x,nb_filter=2048,kernel_size=(5,5),strides=(1,1),padding='same')
x = GlobalAveragePooling2D()(x)

predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=input_layer, outputs=predictions)
model.compile(optimizer='adam', loss='categorical_crossentropy' , metrics = ['accuracy'])  #rmsprop   loss = [focal_loss(gamma=2)],
'''
'''
stl_mdl = Sequential()
model = Model(inputs=input_layer, outputs=b)
stl_mdl.add(SpatialTransformer(localization_net=locnet,output_size=(256,256,3),
                            input_shape=(256,256,3)))
stl_mdl.add(base_model)
'''


'''
#--------VGG19迁移模型-----------------
#coding=utf-8  
from keras.applications.vgg19 import VGG19
from keras.layers import Dense,Flatten,GlobalAveragePooling2D
from keras.layers import Input,Dense,Dropout,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,concatenate  
from keras.optimizers import SGD
from keras.models import Model  
from keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
from keras.models import Sequential  
from keras.layers import Dense,Flatten,Dropout  
from keras.layers.convolutional import Conv2D,MaxPooling2D  
import numpy as np  

base_model = VGG19(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/vgg19_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)

for layer in base_model.layers:
    layer.trainable = False

x = base_model.output

# 增加全连接层
x = GlobalAveragePooling2D()(x)
#x = Dense(1024, activation='relu')(x)
#x = Flatten()(x)

# softmax激活函数用户分类
predictions = Dense(len(classes), activation='softmax')(x)

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)
# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#-------InCV3迁移模型---------------
from keras.applications.inception_v3 import InceptionV3
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K

# 创建预训练模型
base_model = InceptionV3(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/inception_v3_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)

#冻结base_model所有层，这样就可以正确获得bottleneck特征
for layer in base_model.layers:
    layer.trainable = False

# 增加全局平均池化层
x = base_model.output
x = GlobalAveragePooling2D()(x)
# 增加全连接层
#x = Dense(1024, activation='relu')(x)
# softmax激活函数用户分类
predictions = Dense(len(classes), activation='softmax')(x)

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)

# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#coding=utf-8  Resnet-50迁移模型----------------
from keras.utils import plot_model
from keras.applications.resnet50 import ResNet50
from keras.models import Model  
from keras.layers import Input,Dense,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,ZeroPadding2D, GlobalAveragePooling2D   
from keras.layers import add,Flatten  
#from keras.layers.convolutional import Conv2D,MaxPooling2D,AveragePooling2D
from keras.optimizers import SGD  

def Conv2d_BN(x, nb_filter,kernel_size, strides=(1,1), padding='same',name=None):  
    if name is not None:  
        bn_name = name + '_bn'  
        conv_name = name + '_conv'  
    else:  
        bn_name = None  
        conv_name = None  
  
    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,activation='relu',name=conv_name)(x)  
    x = BatchNormalization(axis=3,name=bn_name)(x)  
    return x  

def Conv_Block(inpt,nb_filter,kernel_size,strides=(1,1), with_conv_shortcut=False):  
    x = Conv2d_BN(inpt,nb_filter=nb_filter[0],kernel_size=(1,1),strides=strides,padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[1], kernel_size=(3,3), padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[2], kernel_size=(1,1), padding='same')  
    if with_conv_shortcut:  
        shortcut = Conv2d_BN(inpt,nb_filter=nb_filter[2],strides=strides,kernel_size=kernel_size)  
        x = add([x,shortcut])  
        return x  
    else:  
        x = add([x,inpt])  
        return x  
    
# 创建预训练模型
K.set_learning_phase(0)
Inp = Input((256, 256, 3))
base_model = ResNet50(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5', 
                      include_top=False,input_shape=(256, 256, 3))

#冻结base_model所有层，这样就可以正确获得bottleneck特征
for layer in base_model.layers:
    layer.trainable = False

#--------------直接softmax更改方式：--------------# 
x = base_model.output
x = GlobalAveragePooling2D()(x)
# 增加全连接层
#x = Dense(1024, activation='relu')(x)
# softmax激活函数用户分类
predictions = Dense(len(classes), activation='softmax')(x)

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)

# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#--------Densenet121迁移模型----------------------------------------------------------
#--coding:utf-8--
#获得模型信息的代码
from keras.applications.densenet import DenseNet121,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
 
base_model = DenseNet121(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet121_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
#base_model = DenseNet201(include_top=False)
 
for layer in base_model.layers:
    layer.trainable = False
    
x = base_model.output

x = GlobalAveragePooling2D()(x) 
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)
 
# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''

'''
#---------MobileNetV2迁移学习--------------------------------------------------------------
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

# 创建预训练模型
IMG_SHAPE=(256, 256, 3)

base_model = keras.applications.MobileNetV2(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')


for layer in base_model.layers:
    layer.trainable = False
    
# 增加全局平均池化层
x = base_model.output
x = GlobalAveragePooling2D()(x)
# 增加全连接层
x = Dense(1024, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 

x = Dense(512, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 
# softmax激活函数用户分类
#predictions = Dense(len(ont_hot_labels[0]), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg
predictions = Dense(len(classes), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)
# 编译模型
#model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
model.compile(loss='categorical_crossentropy', optimizer=optimizers.Adadelta(), metrics=['accuracy'])
'''


'''
#--------NASNetmobile迁移模型----------------------------------------------------------
#--coding:utf-8--
#获得模型信息的代码
from keras.applications.densenet import DenseNet121,preprocess_input
from keras.layers import Dense, GlobalAveragePooling2D
from keras.models import Model
from keras import applications, regularizers

IMG_SHAPE=(256, 256, 3)

#base_model = applications.nasnet.NASNetMobile(weights='imagenet', include_top=False)

base_model = applications.nasnet.NASNetMobile(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/NASNet-mobile-no-top.h5', include_top=False,
                                              input_shape=IMG_SHAPE,
                                              classes=len(classes))

 
for layer in base_model.layers:
    layer.trainable = False
    
x = base_model.output

x = GlobalAveragePooling2D()(x) 
predictions = Dense(len(classes), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=predictions)
 
# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy',  metrics = ['accuracy'])  #rmsprop
'''



train_datagen = ImageDataGenerator(validation_split=0.2)
train_datagen.mean = np.array([103.939, 116.779, 123.68], dtype=np.float32).reshape((3, 1, 1))  # 去掉imagenet BGR均值
train_data = train_datagen.flow_from_directory(train_dir, target_size=img_size, classes=classes)
validation_datagen = ImageDataGenerator()
validation_datagen.mean = np.array([103.939, 116.779, 123.68], dtype=np.float32).reshape((3, 1, 1))
validation_data = validation_datagen.flow_from_directory(validation_dir, target_size=img_size, classes=classes)

#model_checkpoint1 = ModelCheckpoint(filepath=MODEL_INIT, save_best_only=True, monitor='val_accuracy', mode='max')
model_checkpoint1 = ModelCheckpoint(filepath=MODEL_INIT, monitor='val_accuracy')
board1 = TensorBoard(log_dir=board_name1,
                     histogram_freq=0,
                     write_graph=True,
                     write_images=True)
callback_list1 = [model_checkpoint1, board1]

model.fit_generator(train_data, steps_per_epoch=nb_train_samples / float(batch_size),
                           epochs = epochs,
                           validation_steps=nb_validation_samples / float(batch_size),
                           validation_data=validation_data,
                           callbacks=callback_list1, verbose=2)


#---------------第二阶段---------------------------------------------
model_checkpoint2 = ModelCheckpoint(filepath=MODEL_PATH,  monitor='val_accuracy')
board2 = TensorBoard(log_dir=board_name2,
                     histogram_freq=0,
                     write_graph=True,
                     write_images=True)
callback_list2 = [model_checkpoint2, board2]

model.load_weights(MODEL_INIT)
for model1 in model.layers:
    model1.trainable = True

model.compile(optimizer=optimizers.SGD(lr=0.0001), loss = [focal_loss(gamma=2)], metrics=['accuracy']) #loss='categorical_crossentropy',


model.fit_generator(train_data, steps_per_epoch=nb_train_samples / float(batch_size), epochs=epochs,
                    validation_data=validation_data, validation_steps=nb_validation_samples / float(batch_size),
                    callbacks=callback_list2, verbose=2)











