﻿from keras import optimizers
import keras.backend.tensorflow_backend as KTF
import glob
from keras.layers import Input,Dense,Dropout,BatchNormalization,Conv2D,MaxPooling2D,AveragePooling2D,concatenate,Activation,ZeroPadding2D
import tensorflow as tf
import cv2
import numpy as np
import pandas as pd
import keras
from keras.models import load_model
from keras.layers import Activation, Dense
from matplotlib import pyplot as plt
from skimage import io,data
import time
from keras import layers
from keras.callbacks import ModelCheckpoint, TensorBoard
from keras.preprocessing.image import ImageDataGenerator

from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
now = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())

import os,sys
os.getcwd()
os.chdir("/home/cjd/15_Com_gen")
#import os
# 
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "1,3"

config = tf.ConfigProto()
config.gpu_options.allow_growth = True
keras.backend.tensorflow_backend.set_session(tf.Session(config=config))


import tensorflow as tf        #定义多分类Focal函数
def focal_loss(gamma=2.):            #多分类，不带alpha
    def focal_loss_fixed(y_true, y_pred):
        pt_1 = tf.where(tf.equal(y_true, 1), y_pred, tf.ones_like(y_pred))
        return -K.sum( K.pow(1. - pt_1, gamma) * K.log(pt_1)) 
    return focal_loss_fixed


def Conv2d_BN(x, nb_filter,kernel_size, padding='same',strides=(1,1),name=None):  
    if name is not None:  
        bn_name = name + '_bn'  
        conv_name = name + '_conv'  
    else:  
        bn_name = None  
        conv_name = None   
    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,activation='relu',name=conv_name)(x)  
#    x = Conv2D(nb_filter,kernel_size,padding=padding,strides=strides,name=conv_name)(x)
#    x = Lambda(swish)(x)
    x = BatchNormalization(axis=3,name=bn_name)(x)  
    return x  


def Conv_Block(inpt,nb_filter,kernel_size,strides=(1,1), with_conv_shortcut=False):  
    x = Conv2d_BN(inpt,nb_filter=nb_filter[0],kernel_size=(1,1),strides=strides,padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[1], kernel_size=(3,3), padding='same')  
    x = Conv2d_BN(x, nb_filter=nb_filter[2], kernel_size=(1,1), padding='same')  
    if with_conv_shortcut:  
        shortcut = Conv2d_BN(inpt,nb_filter=nb_filter[2],strides=strides,kernel_size=kernel_size)  
        x = add([x,shortcut])  
        return x  
    else:  
        x = add([x,inpt])  
        return x  


## 数据集
#train_dir = '/home/wkq/Projects/kerasVGG19/train_b'  # 训练集
#test_dir = '/home/wkq/Projects/kerasVGG19/test_b/Apple___Black_rot'  # 测试集

train_dir = './train_b'  # 训练集
test_dir='./test_b/Potato___Late_blight'  # 测试集

img_size = (256, 256)  # 图片大小
epochs = 50
MODEL_PATH = './obj_reco/tst_model.h5'
board_name1 = './obj_reco/stage1/' + now + '/'
board_name2 = './obj_reco/stage2/' + now + '/'
now = time.strftime("%Y-%m-%d_%H-%M-%S", time.localtime())


# 定义模型
classes = sorted([o for o in os.listdir(train_dir)])  # 根据文件名分类

'''
#---------MobileNet迁移学习----------------------------------------------------------------
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

# 创建预训练模型
IMG_SHAPE=(256, 256, 3)

base_model = keras.applications.mobilenet.MobileNet(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_1_0_224_tf_no_top.h5')

for layer in base_model.layers:
    layer.trainable = False
    
# 增加全局平均池化层
x = base_model.output
x = GlobalAveragePooling2D()(x)
# 增加全连接层
x = Dense(1024, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 

x = Dense(512, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 
# softmax激活函数用户分类
#predictions = Dense(len(ont_hot_labels[0]), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg
predictions = Dense(len(classes), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)
'''


#---------SE-DenseNet迁移学习--------------------------------------------------------------
from keras.applications.densenet import DenseNet121,preprocess_input
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

class SeBlock(keras.layers.Layer):   
    def __init__(self, reduction=4,**kwargs):
        super(SeBlock,self).__init__(**kwargs)
        self.reduction = reduction
    def build(self,input_shape):#构建layer时需要实现
    	#input_shape     
    	pass
    def call(self, inputs):
        x = keras.layers.GlobalAveragePooling2D()(inputs)
        x = keras.layers.Dense(int(x.shape[-1]) // self.reduction, use_bias=False,activation=keras.activations.relu)(x)
        x = keras.layers.Dense(int(inputs.shape[-1]), use_bias=False,activation=keras.activations.hard_sigmoid)(x)
        return keras.layers.Multiply()([inputs,x])    #给通道加权重
        #return inputs*x 

# 创建预训练模型
IMG_SHAPE=(256, 256, 3)

base_model = DenseNet121(weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/densenet121_weights_tf_dim_ordering_tf_kernels_notop.h5', include_top=False)
#base_model = keras.applications.mobilenet.MobileNet(input_shape=IMG_SHAPE,include_top=False, 
#weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_1_0_224_tf_no_top.h5')
#base_model = keras.applications.MobileNetV2(input_shape=IMG_SHAPE,include_top=False, 
#weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')


for layer in base_model.layers:
    layer.trainable = False
    
# 增加全局平均池化层
x = base_model.output
x  = Conv2d_BN(x,nb_filter=512,kernel_size=(3,3),strides=(1,1),padding='same')
x=SeBlock()(x)
x = GlobalAveragePooling2D()(x)

# softmax激活函数用户分类
predictions = Dense(len(classes), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)



'''
#---------MobileNet_SE迁移学习--------------------------------------------------------------
import tensorflow as tf
from keras.preprocessing import image
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D
from keras import backend as K
from keras import regularizers

class SeBlock(keras.layers.Layer):   
    def __init__(self, reduction=4,**kwargs):
        super(SeBlock,self).__init__(**kwargs)
        self.reduction = reduction
    def build(self,input_shape):#构建layer时需要实现
    	#input_shape     
    	pass
    def call(self, inputs):
        x = keras.layers.GlobalAveragePooling2D()(inputs)
        x = keras.layers.Dense(int(x.shape[-1]) // self.reduction, use_bias=False,activation=keras.activations.relu)(x)
        x = keras.layers.Dense(int(inputs.shape[-1]), use_bias=False,activation=keras.activations.hard_sigmoid)(x)
        return keras.layers.Multiply()([inputs,x])    #给通道加权重
        #return inputs*x 

# 创建预训练模型
IMG_SHAPE=(256, 256, 3)
base_model = keras.applications.mobilenet.MobileNet(input_shape=IMG_SHAPE,include_top=False, 
weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_1_0_224_tf_no_top.h5')

#base_model = keras.applications.MobileNetV2(input_shape=IMG_SHAPE,include_top=False, 
#weights='/home/cjd/01_rice_dete/obj_reco/checkpoint/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')

for layer in base_model.layers:
    layer.trainable = False
    
# 增加全局平均池化层
x = base_model.output

#x  = Conv2d_BN(x,nb_filter=2048,kernel_size=(5,5),strides=(1,1),padding='same')
x=SeBlock()(x)
x = GlobalAveragePooling2D()(x)
# 增加全连接层
x = Dense(1024, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 

x = Dense(512, activation='relu', kernel_regularizer=regularizers.l1(0.0001))(x)
x = BatchNormalization()(x)
x = Dropout(0.4)(x) 
# softmax激活函数用户分类
#predictions = Dense(len(ont_hot_labels[0]), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg
predictions = Dense(len(classes), activation='softmax', kernel_regularizer =regularizers.l2(0.01) )(x)  #l1_reg

# 预训练模型与新加层的组合
model = Model(inputs=base_model.input, outputs=predictions)
'''


model.load_weights(MODEL_PATH)
# --------------- 测试 ----------------
dirs = os.listdir(test_dir)

prob_list = []
for d in dirs:
    img = image.load_img(test_dir + os.sep + d, target_size=img_size)
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    y = model.predict(x)
#    print(y)
    print(classes[np.argmax(y)])
#    print(classes)

    prob_list.append(str(y))   #结果存入txt文本 
    file=open('pred_prob.txt','w') 
    file.write('\n'.join(prob_list))
    file.close() 